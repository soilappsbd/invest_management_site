<br/>
<div class="row">
	<div class="col-md-12">

		<table class="table table-responsive table-stripe table-bordered">
			<tr> 
				<th> Member</th> 
                <th> Stats</th> 
				<th> Deposit</th>
                <th> Stats</th>  
				<th> Referral</th> 
                <th> Stats</th> 
				<th> Withdraw</th> 
                <th> Stats</th> 
	
			</tr>
			<?php if($list){?>
			<?php foreach($list as $arr){?>
			<tr> 
				<td>Active Member</td> 
				<td> <?php echo $totalmember;  ?></td> 
				<td> BDt despo</td> 
			    <td> 5555</td> 
				<td> referal tota</td> 
                <td> 5555</td>
                <td> totalwithdraw</td> 
                <td> 5555</td>
			</tr>
			<?php }
				}
			?>
		</table>
                                                              


	</div>
</div>


<br><br>
<br>