<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">
  <!--<link rel="shortcut icon" href="../images/favicon.png" type="image/png">-->

  <title>Adminsitration Panel</title>

  <link rel="stylesheet" href="<?php echo base_url();?>assetsadmin/lib/Hover/hover.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assetsadmin/lib/fontawesome/css/font-awesome.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assetsadmin/lib/weather-icons/css/weather-icons.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assetsadmin/lib/ionicons/css/ionicons.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assetsadmin/lib/jquery-toggles/toggles-full.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assetsadmin/lib/morrisjs/morris.css">

  <link rel="stylesheet" href="<?php echo base_url();?>assetsadmin/css/quirk.css">
 

  <script src="<?php echo base_url();?>assetsadmin/lib/modernizr/modernizr.js"></script>



    <link rel="stylesheet" href="<?php echo base_url();?>assetsadmin/lib/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

  <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="../lib/html5shiv/html5shiv.js"></script>
  <script src="../lib/respond/respond.src.js"></script>
  <![endif]-->
</head>