<header>
  <div class="headerpanel">

    <div class="logopanel">
      <h2><a href="index.html">Admin</a></h2>
    </div><!-- logopanel -->

    <div class="headerbar">

      <a id="menuToggle" class="menutoggle"><i class="fa fa-bars"></i></a>

      <div class="header-right">
        <ul class="headermenu">
     
          <li>
            <div class="" style="margin-top: 20px;">
               <a href="<?php echo base_url();?>signout"><i class="glyphicon glyphicon-log-out"></i> Log Out</a>
            </div>
          </li>
        </ul>
      </div><!-- header-right -->
    </div><!-- headerbar -->
  </div><!-- header-->
</header>