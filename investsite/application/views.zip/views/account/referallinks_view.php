<br/>
<div class="row">
	<div class="col-md-12">


			
			










				

			        <center>
    <h4 class="banner-head">Banner : 125x125</h4><br>

<img style="margin: 0 auto;display: table;" src="images/125.gif">

<br>


<textarea style="width: 95%;" class="inpts" cols="60" rows="4">

 <?php echo base_url();?>?ref=<?php echo $commondata['memberinfo']['0']->username;?>

</textarea><br><br>


<h4 class="banner-head">Banner : 468x60</h4><br>

<img style="margin: 0 auto;display: table;" src="images/468.gif">
<br>


<textarea style="width: 95%;" class="inpts" cols="60" rows="4">

 <?php echo base_url();?>?ref=<?php echo $commondata['memberinfo']['0']->username;?>

</textarea><br><br>


<h4 class="banner-head">Banner : 728x90</h4><br>
<img style="margin: 0 auto;display: table;" src="images/728.gif">
<br>


<textarea style="width: 95%;" class="inpts" cols="60" rows="4">
 <?php echo base_url();?>?ref=<?php echo $commondata['memberinfo']['0']->username;?>

</textarea><br><br>


<h4 class="banner-head">Banner : 300x300</h4><br>
<img style="margin: 0 auto;display: table;" src="images/300.gif">
<br>


<textarea style="width: 95%;" class="inpts" cols="60" rows="4">
 <?php echo base_url();?>?ref=<?php echo $commondata['memberinfo']['0']->username;?>

</textarea><br><br>

<h4 class="banner-head">Banner : 160x600</h4><br>
<img style="margin: 0 auto;display: table;" src="images/160.gif">
<br>


<textarea style="width: 95%;" class="inpts" cols="60" rows="4">
 <?php echo base_url();?>?ref=<?php echo $commondata['memberinfo']['0']->username;?>

</textarea><br><br>

</center>
	
				
				
				
				
				
				
				


                                  	
				
				
				
				
				
	
				
				
				


                            		
				
				
				

                                                              
<br><br>
<br>

	</div>
</div>