					<div class="row">
						<div class="col-md-12">
							<div class="infobox">

								<div class="row">
									<div class="col-md-4">
										<div class="acr_Part1 acr_Part11">
											<h4>username:</h4>
											<h3><?php echo $commondata['memberinfo']['0']->username;?></h3>
										</div>
									</div>
									<div class="col-md-4">	
										<div class="acr_Part1 acr_Part12">
											<h4>Registration Date:</h4>
											<h3><?php echo date("d-M-Y",$commondata['memberinfo']['0']->updatetime);?></h3>
										</div>
									</div>
									<div class="col-md-4">	
										<div class="acr_Part1 acr_Part13">
											<h4>Total Invest:</h4>
											<h3><?php echo 0;?></h3>
										</div>
									</div>	
								</div>		
							</div>
						</div>	
					</div>
					<div class="row">
						<div class="col-md-12">
							<div style="margin: auto; height: 300px;">
							<br/>
							<br/>
							<br/>
								<h2 style="color: red" class="text-center"> Your Account is Susspended Temporarily. Please contact to Support. </h2>	
							</div>
						</div>
					</div>					