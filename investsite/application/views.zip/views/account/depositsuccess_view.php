<br/>
<div class="row">
	<div class="col-md-12">


			<h1> Deposit Received Successfully</h1>

		                                                              
		<br><br>
		<br>
	</div>
</div>