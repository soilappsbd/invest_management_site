<br/>
<div class="row">
	<div class="col-md-12">
		<table class="table table-responsive table-stripe table-bordered">
			<tbody>
			<tr>
			 <td>Plan:</td>
			 <td><?php echo $packageid;?></td>
			
			</tr>
			<tr>
			 <td>Profit:</td>
			 <td><?php echo $tagline;?> </td>
			</tr>
			<tr>
			 <td>Principal Return:</td>
			 <td>Principal Included</td>
			</tr>
			
			 

			<tr>
			 <td>Credit Amount:</td>
			 <td>$<?php echo $investamoun;?></td>
			</tr>
			<tr>
			 <td>Deposit Fee:</td>
			 <td>0.00% + $0.00 (min. $0.00 max. $0.00)</td>
			</tr>
			<tr>
			 <td>Debit Amount:</td>
			 <td>$<?php echo $investamoun;?></td>
			</tr>
			</tbody>
		</table>
	</div>	
</div>	
		<?php 
		if($payoption=="pm"){
		?>
		<form action="https://perfectmoney.is/api/step1.asp" method="POST">
			<input type="hidden" name="PAYEE_ACCOUNT" value="U4421212">
			<input type="hidden" name="PAYEE_NAME" value="Investment-Lover">
			<input type="hidden" name="PAYMENT_ID" value="<?php echo time();?>">
			<input type="hidden" name="PAYMENT_AMOUNT" value="<?php echo $investamoun;?>">
			<input type="hidden" name="PAYMENT_UNITS" value="USD">
			<input type="hidden" name="STATUS_URL" value="mailto:softgeekzteam@gmail.com">
			<input type="hidden" name="PAYMENT_URL" value="http://investment-lover.com/account/depositsuccess">
			<input type="hidden" name="PAYMENT_URL_METHOD" value="POST">
			<input type="hidden" name="NOPAYMENT_URL" value="http://investment-lover.com/deposit/unsuccess">
			<input type="hidden" name="NOPAYMENT_URL_METHOD" value="POST">
			<input type="hidden" name="SUGGESTED_MEMO" value="">
			<input type="hidden" name="planid" value="2">
			<input type="hidden" name="BAGGAGE_FIELDS" value="planid">
			

			<div class="row">
				<div class="form-group col-md-6 text-center">
					<input type="submit" name="PAYMENT_METHOD" value="Pay Now!">
				</div>
				<div class="form-group col-md-6 text-center">
					<a href="<?php echo base_url(); ?>account/deposit" class="btn btn-warning"> Cancel</a>
				</div>
			</div>

			</form>
		<?php }elseif($payoption=="abpm"){
				echo "Will Be Paid From Your PerfectMoney account Balance";
			  }elseif($payoption=="abbtc"){
				echo "Will Be Paid From Your Bitcoin account Balance";  
			  }elseif($payoption=="btc"){
				echo 'Please Pay to BTC : <span style="font-weight: bold; color: green">'. $receivebtcid .'</span>';
				echo "<br/>";
				echo "<br/>";
				echo "Order status: Waiting for payment (Deposit will be Automaticly Updated after Payment)";
			  }
		?>	
		
		
<!--<script language="javascript"> setTimeout("location.reload()", 30000); </script>
function executeQuery() {
  $.ajax({
    url: 'url/path/here',
    success: function(data) {
      // do something with the return value here if you like
    }
  });
  setTimeout(executeQuery, 5000); // you could choose not to continue on failure...
}

$(document).ready(function() {
  // run the first time; all subsequent calls will take care of themselves
  setTimeout(executeQuery, 5000);
});

	-->	
