<div class="contentInner">

<p class="white" align="justify">
        Free quently 
</p>
</div>