   <div class=" form-block">
            <div class="form-title">Account Information</div>
            <table cellspacing=0 cellpadding=2 border=0>
                <tr>
                 <td width="200">Full Name:</td>
                 <td><input type=text name=fullname value="" class=inpts size=30></td>
                </tr>
                <tr>
                 <td>Username:</td>
                 <td><input type=text name=username value="" class=inpts size=30></td>
                </tr>
                <tr>
                 <td>Define Password:</td>
                 <td><input type=password name=password value="" class=inpts size=30></td>
                </tr><tr>
                 <td>Retype Password:</td>
                 <td><input type=password name=password2 value="" class=inpts size=30></td>
                </tr>

                <tr>
                 <td>E-mail Address:</td>
                 <td><input type=text name=email value="" class=inpts size=30></td>
                </tr>
                <tr>
                 <td>Retype E-mail:</td>
                 <td><input type=text name=email1 value="" class=inpts size=30></td>
                </tr>
                <tr>
                 <td>Secret question:</td>
                 <td><input type=text name=sq value="" class=inpts size=30></td>
                </tr>
                <tr>
                 <td>Secret answer:</td>
                 <td><input type=text name=sa value="" class=inpts size=30></td>
                </tr>
            </table>
       </div>