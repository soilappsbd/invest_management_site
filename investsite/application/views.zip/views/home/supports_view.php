<div class="contentinner">

<div class="support-container">

<div class="support-left">
    
    <div class="address"> 
    
    <h2 class="white">suntrade.trade </h2>
    <p class="white">
    JOHN ECCLES HOUSE, <br>
    ROBERT ROBINSON AVENU, <br>
    OXFORD SCIENCE PARK, <br>
    OXFORD, OX4 4GP , ENGLAND <br>
    </p>
    </div>
    
    <p class="email white">Contact us via e-mail: <a class="white" href="mailto:admin@bittradeuk.com">admin@bittradeuk.com</a></p>


</div>

<div class="support-right">
<h3 class="white">Support Form:</h3><br>



<script src="/cdn-cgi/scripts/0e574bed/cloudflare-static/email-decode.min.js"></script><script language="javascript">

function checkform() {
  if (document.mainform.name.value == '') {
    alert("Please type your full name!");
    document.mainform.name.focus();
    return false;
  }
  if (document.mainform.email.value == '') {
    alert("Please enter your e-mail address!");
    document.mainform.email.focus();
    return false;
  }
  if (document.mainform.message.value == '') {
    alert("Please type your message!");
    document.mainform.message.focus();
    return false;
  }
  return true;
}

</script>
<form method="post" name="mainform" onsubmit="return checkform()">
<input type="hidden" name="a" value="support">
<input type="hidden" name="action" value="send">

 
<table cellspacing="0" cellpadding="2" border="0">
<tbody><tr>
 <td class="white">Your Name:</td>
 <td>
     
     
     
       
     <input type="text" name="name" value="tariq" readonly="" size="30" class="inpts">
     
       
     
     
 </td>
</tr>
<tr>
 <td class="white">Your Email:</td>
 <td>
     
     
     
     
          
     <input type="text" name="email" value="softgeekzteam@gmail.com" readonly="" size="30" class="inpts">
     
       
     
     
 </td>
</tr>
<tr>
 <td colspan="2" class="white">Message:<br><br><textarea name="message" class="inpts" cols="45" rows="4"></textarea>
</td></tr>
<tr>
 <td>&nbsp;</td>
 <td><input type="submit" value="Send" class="sbmt"></td>
</tr></tbody></table>
</form>
</div>
</div>
</div>