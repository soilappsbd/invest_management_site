<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Coinbase extends CI_Controller {

	public function index(){
		echo "Conbase tester";
	}
	
	
	public function generateaddress(){
		$coinapi = ""; 
		require_once APPPATH.'third_party/Coinbase/Address.php';
		$this->coinapi = new Address();

		echo $this->coinapi->GenerateNewAddress();
	}
	
	
	public function priceusd(){
		echo file_get_contents("https://api.coinbase.com/v1/prices/spot_rate?currency=USD");
	}


	
	
}
